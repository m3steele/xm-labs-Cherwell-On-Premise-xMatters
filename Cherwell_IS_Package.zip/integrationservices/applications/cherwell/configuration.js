// ----------------------------------------------------------------------------------------------------
// Configuration settings for an xMatters Relevance Engine Integration
// ----------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------
// The url that will be used to inject events into xMatters.
// ----------------------------------------------------------------------------------------------------

// xMatters Inbound Integration Endpoint URL for New Incident One Step
WEB_SERVICE_URL = "https://companyname.xmatters.com/api/integration/1/functions/6dc335339/triggers";

// xMatters Inbound Integration Endpoint URL for Terminate Events
WEB_SERVICE_TERMINATE_URL = "https://companyname.xmatters.com/api/integration/1/functions/c091db074/triggers";

// xMatters ondemand base url no trailing slash
XMATTERS_ONDEMAND = "https://companyname.xmatters.com";



// CHERWELL JOURNAL RECORD PARAMETERS
// Values provided below are most likely correct but you should still check your cherwell environment.

// Replace with Your Cherwell Journal TypeID if it is different
CHERWELL_JOURNAL_TYPEID = "934d8181ba9d3a6a506d7643e1bc71f70fa9b47412";

// Replace with Cherwell Journal Type Name if it is different
CHERWELL_JOURNAL_TYPENAME = "Journal - Note";

// Replace with Cherwell Incident Business Object ID if it is different
CHERWELL_INCIDENT_OBJID = "6dd53665c0c24cab86870a21cf6434ae";

// Replace with Cherwell Task Business Object ID if it is different
CHERWELL_TASK_OBJID = "9355d5ed41e384ff345b014b6cb1c6e748594aea5b";

// Cherwell Server Address
CHERWELL_SERVER = "http://yourserveraddress.com";



//----------------------------------------------------------------------------------------------------
// The username and password used to authenticate the request to xMatters.
// The PASSWORD value is a path to a file where the
// user's password should be encrypted using the iapassword.sh utility.
// Please see the integration agent documentation for instructions.
//----------------------------------------------------------------------------------------------------
INITIATOR = "Cherwell_API_User";
// Path to encrypted password containing xMatters webservice user password. 
// See Integration Agent Documention on how to create this file using iapassword.sh utility.
PASSWORD = "integrationservices/applications/cherwell/.initiatorpasswd";

//----------------------------------------------------------------------------------------------------
// Cherwell Webservice User Key / ID
//----------------------------------------------------------------------------------------------------
CHERWELL_WS_ID = "01fad7a1-f295-4f9f-98f7-ed1faa77ebd1";

// Cherwell Webservice User Name
CHERWELL_WS_USER = "xMatters";

// Path to encrypted password containing Cherwell webservice user password. 
// See Integration Agent Documention on how to create this file using iapassword.sh utility.
CHERWELL_WS_PASSWORD = "integrationservices/applications/cherwell/.chwspasswd";


// ----------------------------------------------------------------------------------------------------
// Callbacks requested for this integration service.
// ----------------------------------------------------------------------------------------------------
CALLBACKS = ["status", "response", "deliveryStatus"];


// ----------------------------------------------------------------------------------------------------
// Filter to use in <IAHOME>/conf/deduplicator-filter.xml
// ----------------------------------------------------------------------------------------------------
//DEDUPLICATION_FILTER_NAME = "sample-relevance-engine";

